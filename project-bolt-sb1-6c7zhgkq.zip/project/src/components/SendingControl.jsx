function SendingControl({ onSend, sending, stats }) {
  return (
    <div className="section">
      <div className="section-header">
        <span>🚀 SENDING CONTROL</span>
      </div>

      <div className="stats">
        <div className="stat-card">
          <div className="stat-value">{stats.total}</div>
          <div className="stat-label">Total</div>
        </div>
        <div className="stat-card">
          <div className="stat-value" style={{ color: '#4caf50' }}>{stats.sent}</div>
          <div className="stat-label">Sent</div>
        </div>
        <div className="stat-card">
          <div className="stat-value" style={{ color: '#f44336' }}>{stats.failed}</div>
          <div className="stat-label">Failed</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.progress}%</div>
          <div className="stat-label">Progress</div>
        </div>
      </div>

      {sending && (
        <div className="progress-bar">
          <div className="progress-fill" style={{ width: `${stats.progress}%` }}>
            {stats.progress}%
          </div>
        </div>
      )}

      <div style={{ textAlign: 'center', marginTop: '20px' }}>
        <button
          className="btn btn-primary"
          onClick={onSend}
          disabled={sending}
          style={{ fontSize: '1.1rem', padding: '15px 40px' }}
        >
          {sending ? '⏳ Sending...' : '📤 Send Messages'}
        </button>
      </div>

      {sending && (
        <div style={{ marginTop: '15px', textAlign: 'center', color: '#666', fontSize: '0.9rem' }}>
          Sending in progress... Please wait
        </div>
      )}
    </div>
  )
}

export default SendingControl
