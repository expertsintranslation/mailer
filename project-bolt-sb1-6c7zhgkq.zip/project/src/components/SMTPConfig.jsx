import { useState } from 'react'

function SMTPConfig({ servers, setServers, sendingConfig, setSendingConfig }) {
  const [currentServer, setCurrentServer] = useState({
    host: '',
    port: '25',
    username: '',
    password: '',
    security: 'NON',
    bccMode: 'NOBCC'
  })

  const addServer = () => {
    if (!currentServer.host || !currentServer.port) {
      alert('Please fill Host and Port')
      return
    }

    const serverString = `${currentServer.host}:${currentServer.port}:${currentServer.username}:${currentServer.password}:${currentServer.security}:${currentServer.bccMode}`
    setServers([...servers, serverString])

    // Reset form
    setCurrentServer({
      host: '',
      port: '25',
      username: '',
      password: '',
      security: 'NON',
      bccMode: 'NOBCC'
    })
  }

  const resetServers = () => {
    setServers([])
  }

  return (
    <div className="section">
      <div className="section-header">
        <span>🖥️ SERVER SETUP</span>
        <span style={{ fontSize: '0.9rem' }}>
          Debug Level:
          <select
            value={sendingConfig.debugLevel}
            onChange={(e) => setSendingConfig({ ...sendingConfig, debugLevel: e.target.value })}
            style={{ marginLeft: '10px', padding: '5px', borderRadius: '4px', border: '1px solid white' }}
          >
            <option value="0">OFF</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
          </select>
        </span>
      </div>

      <div className="form-row">
        <label>SMTP IP:</label>
        <input
          type="text"
          value={currentServer.host}
          onChange={(e) => setCurrentServer({ ...currentServer, host: e.target.value })}
          placeholder="smtp.example.com"
        />
      </div>

      <div className="form-row">
        <label>SMTP LOGIN:</label>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <input
            type="text"
            value={currentServer.username}
            onChange={(e) => setCurrentServer({ ...currentServer, username: e.target.value })}
            placeholder="Username"
          />
          <input
            type="password"
            value={currentServer.password}
            onChange={(e) => setCurrentServer({ ...currentServer, password: e.target.value })}
            placeholder="Password"
          />
        </div>
      </div>

      <div className="form-row">
        <label>Port:</label>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <input
            type="text"
            value={currentServer.port}
            onChange={(e) => setCurrentServer({ ...currentServer, port: e.target.value })}
            placeholder="25"
            style={{ width: '100px' }}
          />
          <button className="btn btn-primary" onClick={addServer}>
            Add SMTP
          </button>
        </div>
      </div>

      <div className="form-row">
        <label>SSL Server:</label>
        <div className="checkbox-group">
          <input
            type="radio"
            name="security"
            value="SSL"
            checked={currentServer.security === 'SSL'}
            onChange={(e) => setCurrentServer({ ...currentServer, security: e.target.value })}
          />
          <label>SSL</label>
          <input
            type="radio"
            name="security"
            value="TLS"
            checked={currentServer.security === 'TLS'}
            onChange={(e) => setCurrentServer({ ...currentServer, security: e.target.value })}
          />
          <label>TLS</label>
          <input
            type="radio"
            name="security"
            value="NON"
            checked={currentServer.security === 'NON'}
            onChange={(e) => setCurrentServer({ ...currentServer, security: e.target.value })}
          />
          <label>NON</label>
        </div>
      </div>

      <div className="form-row">
        <label>IS BCC:</label>
        <div className="checkbox-group">
          <input
            type="checkbox"
            checked={currentServer.bccMode === 'BCC'}
            onChange={(e) => setCurrentServer({ ...currentServer, bccMode: e.target.checked ? 'BCC' : 'NOBCC' })}
          />
          <label>Yes</label>
        </div>
      </div>

      <div className="form-row">
        <label>SMTP CONFIG:</label>
        <div>
          <div className="smtp-list">
            {servers.length === 0 ? (
              <span style={{ color: '#999' }}>No SMTP servers added yet...</span>
            ) : (
              servers.map((server, index) => (
                <div key={index} style={{ marginBottom: '5px' }}>
                  {server}
                </div>
              ))
            )}
          </div>
          <div style={{ display: 'flex', gap: '10px', marginTop: '10px', alignItems: 'center' }}>
            <span>Every</span>
            <input
              type="number"
              value={sendingConfig.rotateEvery}
              onChange={(e) => setSendingConfig({ ...sendingConfig, rotateEvery: e.target.value })}
              style={{ width: '80px' }}
              placeholder="0"
            />
            <span>EMAILS</span>
            <button className="btn btn-danger" onClick={resetServers}>
              Reset
            </button>
          </div>
        </div>
      </div>

      <div className="form-row">
        <label>SEND PAUSE:</label>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
          <input
            type="number"
            value={sendingConfig.pauseSeconds}
            onChange={(e) => setSendingConfig({ ...sendingConfig, pauseSeconds: e.target.value })}
            style={{ width: '80px' }}
            placeholder="0"
          />
          <span>sec every</span>
          <input
            type="number"
            value={sendingConfig.pauseEveryEmails}
            onChange={(e) => setSendingConfig({ ...sendingConfig, pauseEveryEmails: e.target.value })}
            style={{ width: '80px' }}
            placeholder="0"
          />
          <span>emails</span>
          <span style={{ color: 'red', fontSize: '12px' }}>(1 bcc = 1 email)</span>
        </div>
      </div>

      <div className="form-row">
        <label>RECONNECT AFTER:</label>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <input
            type="number"
            value={sendingConfig.reconnectAfter}
            onChange={(e) => setSendingConfig({ ...sendingConfig, reconnectAfter: e.target.value })}
            style={{ width: '80px' }}
            placeholder="0"
          />
          <span>EMAILS</span>
        </div>
      </div>

      <div className="form-row">
        <label>NUM OF EMAIL IN BCC:</label>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <input
            type="number"
            value={sendingConfig.bccCount}
            onChange={(e) => setSendingConfig({ ...sendingConfig, bccCount: e.target.value })}
            style={{ width: '100px' }}
            placeholder="100"
          />
          <span>EMAILS</span>
        </div>
      </div>

      <div style={{ marginTop: '20px', padding: '15px', background: '#fff3cd', borderRadius: '6px', border: '1px solid #ffc107' }}>
        <p style={{ color: '#856404', textAlign: 'center', fontSize: '0.95rem', fontWeight: '600' }}>
          " IF YOU DON'T HAVE SMTP LOGIN INFORMATION, LEAVE BLANK TO SEND WITH LOCALHOST "
        </p>
      </div>
    </div>
  )
}

export default SMTPConfig
