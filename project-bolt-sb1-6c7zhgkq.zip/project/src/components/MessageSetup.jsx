import { useState } from 'react'

function MessageSetup({ config, setConfig, sendingConfig, setSendingConfig }) {
  const [patternConfig, setPatternConfig] = useState({
    az: false,
    AZ: false,
    num: false,
    length: ''
  })

  const generatePattern = () => {
    if (!patternConfig.length || (!patternConfig.az && !patternConfig.AZ && !patternConfig.num)) {
      alert('Please select at least one character type and specify length')
      return
    }

    let pattern = '##'
    if (patternConfig.az) pattern += 'az-'
    if (patternConfig.AZ) pattern += 'AZ-'
    if (patternConfig.num) pattern += '09-'
    pattern = pattern.slice(0, -1) // Remove last dash
    pattern += `{${patternConfig.length}}##`

    // Add pattern to message/subject at cursor position
    alert(`Pattern generated: ${pattern}\n\nYou can use this in your subject or message to generate random strings.`)
  }

  return (
    <div className="section">
      <div className="section-header">
        <span>✉️ MESSAGE SETUP</span>
      </div>

      <div className="form-row">
        <label>Your Email:</label>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <input
            type="email"
            value={config.from}
            onChange={(e) => setConfig({ ...config, from: e.target.value })}
            placeholder="sender@example.com"
            disabled={config.useLoginAsEmail}
            style={{ flex: 1 }}
          />
          <div className="checkbox-group">
            <input
              type="checkbox"
              checked={config.useLoginAsEmail}
              onChange={(e) => setConfig({ ...config, useLoginAsEmail: e.target.checked })}
            />
            <label>EMAIL as LOGIN</label>
          </div>
        </div>
      </div>

      <div className="form-row">
        <label>Your Name:</label>
        <input
          type="text"
          value={config.fromName}
          onChange={(e) => setConfig({ ...config, fromName: e.target.value })}
          placeholder="Sender Name"
        />
      </div>

      <div className="form-row">
        <label>Reply-To:</label>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <input
            type="email"
            value={config.replyTo}
            onChange={(e) => setConfig({ ...config, replyTo: e.target.value })}
            placeholder="reply@example.com"
            disabled={config.useLoginAsReply}
            style={{ flex: 1 }}
          />
          <div className="checkbox-group">
            <input
              type="checkbox"
              checked={config.useLoginAsReply}
              onChange={(e) => setConfig({ ...config, useLoginAsReply: e.target.checked })}
            />
            <label>REPLY as LOGIN</label>
          </div>
          <div className="checkbox-group">
            <input
              type="checkbox"
              checked={config.confirmReading}
              onChange={(e) => setConfig({ ...config, confirmReading: e.target.checked })}
            />
            <label>CONFIRM READING</label>
          </div>
        </div>
      </div>

      <div className="form-row">
        <label>Email Priority:</label>
        <select
          value={config.priority}
          onChange={(e) => setConfig({ ...config, priority: e.target.value })}
        >
          <option value="">NO PRIORITY</option>
          <option value="1">HIGH</option>
          <option value="3">NORMAL</option>
          <option value="5">LOW</option>
        </select>
      </div>

      <div className="form-row">
        <label>Subject:</label>
        <input
          type="text"
          value={config.subject}
          onChange={(e) => setConfig({ ...config, subject: e.target.value })}
          placeholder="Email Subject"
        />
      </div>

      <div className="form-row">
        <label>Encoding:</label>
        <div style={{ display: 'flex', gap: '10px' }}>
          <select
            value={config.encoding}
            onChange={(e) => setConfig({ ...config, encoding: e.target.value })}
          >
            <option value="no">NO</option>
            <option value="8bit">8bit</option>
            <option value="7bit">7bit</option>
            <option value="binary">binary</option>
            <option value="base64">base64</option>
            <option value="quoted-printable">quoted-printable</option>
          </select>
          <select
            value={config.charset}
            onChange={(e) => setConfig({ ...config, charset: e.target.value })}
          >
            <option value="">NO CHARSET</option>
            <option value="us-ascii">Unicode - us-ascii</option>
            <option value="utf-7">Unicode - utf-7</option>
            <option value="utf-8">Unicode - utf-8</option>
            <option value="iso-8859-6">Arabic - iso-8859-6</option>
            <option value="windows-1256">Arabic - windows-1256</option>
          </select>
        </div>
      </div>

      <div className="form-row">
        <label>Generator:</label>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
          <div className="checkbox-group">
            <input
              type="checkbox"
              checked={patternConfig.az}
              onChange={(e) => setPatternConfig({ ...patternConfig, az: e.target.checked })}
            />
            <label>(a-z)</label>
          </div>
          <div className="checkbox-group">
            <input
              type="checkbox"
              checked={patternConfig.AZ}
              onChange={(e) => setPatternConfig({ ...patternConfig, AZ: e.target.checked })}
            />
            <label>(A-Z)</label>
          </div>
          <div className="checkbox-group">
            <input
              type="checkbox"
              checked={patternConfig.num}
              onChange={(e) => setPatternConfig({ ...patternConfig, num: e.target.checked })}
            />
            <label>(0-9)</label>
          </div>
          <span>(LENGTH)</span>
          <input
            type="number"
            value={patternConfig.length}
            onChange={(e) => setPatternConfig({ ...patternConfig, length: e.target.value })}
            style={{ width: '60px' }}
            placeholder="10"
          />
          <button className="btn btn-secondary" onClick={generatePattern}>
            GET PATTERN
          </button>
        </div>
      </div>

      <div className="form-row">
        <label>Attach:</label>
        <input
          type="file"
          onChange={(e) => setSendingConfig({ ...sendingConfig, attachment: e.target.files[0] })}
        />
      </div>

      <div className="form-row full">
        <div style={{ display: 'grid', gridTemplateColumns: '3fr 1fr', gap: '20px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '10px', fontWeight: '600' }}>
              Message Body:
            </label>
            <textarea
              value={config.message}
              onChange={(e) => setConfig({ ...config, message: e.target.value })}
              style={{ minHeight: '200px', width: '100%' }}
              placeholder="Enter your message here..."
            />
            <div style={{ marginTop: '10px', display: 'flex', gap: '10px', alignItems: 'center' }}>
              <div className="checkbox-group">
                <input
                  type="radio"
                  name="contentType"
                  value="plain"
                  checked={config.contentType === 'plain'}
                  onChange={(e) => setConfig({ ...config, contentType: e.target.value })}
                />
                <label>TEXT</label>
              </div>
              <div className="checkbox-group">
                <input
                  type="radio"
                  name="contentType"
                  value="html"
                  checked={config.contentType === 'html'}
                  onChange={(e) => setConfig({ ...config, contentType: e.target.value })}
                />
                <label>HTML</label>
              </div>
            </div>
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: '10px', fontWeight: '600' }}>
              Email List:
            </label>
            <textarea
              value={config.emailList}
              onChange={(e) => setConfig({ ...config, emailList: e.target.value })}
              style={{ minHeight: '200px', width: '100%' }}
              placeholder="email1@example.com&#10;email2@example.com&#10;email3@example.com"
            />
            <div className="helper-text" style={{ marginTop: '10px' }}>
              One email per line
            </div>
          </div>
        </div>
      </div>

      <div style={{ marginTop: '15px', padding: '12px', background: '#e7f3ff', borderRadius: '6px', border: '1px solid #2196F3' }}>
        <p style={{ color: '#1976d2', fontSize: '0.9rem', margin: 0 }}>
          <strong>Available Tags:</strong> !!EMAIL!! (recipient email), !!DATE!! (current date), !!TIME!! (current time)
        </p>
      </div>
    </div>
  )
}

export default MessageSetup
