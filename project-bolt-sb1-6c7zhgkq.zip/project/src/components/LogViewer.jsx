import { useEffect, useRef } from 'react'

function LogViewer({ logs }) {
  const logContainerRef = useRef(null)

  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight
    }
  }, [logs])

  const getLogClassName = (type) => {
    return `log-line ${type}`
  }

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString()
  }

  return (
    <div className="section">
      <div className="section-header">
        <span>📋 LOGS</span>
        <span style={{ fontSize: '0.9rem' }}>{logs.length} entries</span>
      </div>

      <div className="log-container" ref={logContainerRef}>
        {logs.length === 0 ? (
          <div className="log-line info">No logs yet...</div>
        ) : (
          logs.map((log, index) => (
            <div key={index} className={getLogClassName(log.type)}>
              <span style={{ opacity: 0.7 }}>[{formatTimestamp(log.timestamp)}]</span>{' '}
              {log.message}
            </div>
          ))
        )}
      </div>
    </div>
  )
}

export default LogViewer
