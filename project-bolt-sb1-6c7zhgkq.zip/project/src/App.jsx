import { useState } from 'react'
import SMTPConfig from './components/SMTPConfig'
import MessageSetup from './components/MessageSetup'
import SendingControl from './components/SendingControl'
import LogViewer from './components/LogViewer'

function App() {
  const [smtpServers, setSmtpServers] = useState([])
  const [messageConfig, setMessageConfig] = useState({
    from: '',
    fromName: '',
    replyTo: '',
    subject: '',
    message: '',
    contentType: 'html',
    emailList: '',
    priority: '',
    encoding: 'no',
    charset: '',
    useLoginAsEmail: false,
    useLoginAsReply: false,
    confirmReading: false
  })
  const [sendingConfig, setSendingConfig] = useState({
    reconnectAfter: 0,
    pauseSeconds: 0,
    pauseEveryEmails: 0,
    rotateEvery: 0,
    debugLevel: '0',
    isBCC: false,
    bccCount: 100,
    attachment: null
  })
  const [logs, setLogs] = useState([])
  const [sending, setSending] = useState(false)
  const [stats, setStats] = useState({
    sent: 0,
    failed: 0,
    total: 0,
    progress: 0
  })

  const addLog = (message, type = 'info') => {
    setLogs(prev => [...prev, { message, type, timestamp: new Date().toISOString() }])
  }

  const handleSend = async () => {
    if (smtpServers.length === 0) {
      alert('Please add at least one SMTP server')
      return
    }

    if (!messageConfig.from || !messageConfig.subject || !messageConfig.message || !messageConfig.emailList) {
      alert('Please fill all required fields (From, Subject, Message, Email List)')
      return
    }

    const emails = messageConfig.emailList.split(/\r?\n/).filter(e => e.trim())
    if (emails.length === 0) {
      alert('Please provide at least one email address')
      return
    }

    setSending(true)
    setStats({ sent: 0, failed: 0, total: emails.length, progress: 0 })
    setLogs([])
    addLog(`Starting email campaign - ${emails.length} recipients`, 'info')

    try {
      const formData = new FormData()
      formData.append('smtpServers', JSON.stringify(smtpServers))
      formData.append('messageConfig', JSON.stringify(messageConfig))
      formData.append('sendingConfig', JSON.stringify(sendingConfig))
      formData.append('emails', JSON.stringify(emails))

      if (sendingConfig.attachment) {
        formData.append('attachment', sendingConfig.attachment)
      }

      const response = await fetch('/api/send-emails', {
        method: 'POST',
        body: formData
      })

      if (!response.ok) {
        throw new Error('Failed to send emails')
      }

      // Use ReadableStream to get real-time updates
      const reader = response.body.getReader()
      const decoder = new TextDecoder()

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        const chunk = decoder.decode(value)
        const lines = chunk.split('\n')

        for (const line of lines) {
          if (!line.trim()) continue

          try {
            const data = JSON.parse(line)

            if (data.type === 'log') {
              addLog(data.message, data.level)
            } else if (data.type === 'progress') {
              setStats(prev => ({
                ...prev,
                sent: data.sent,
                failed: data.failed,
                progress: Math.round((data.sent + data.failed) / emails.length * 100)
              }))
            } else if (data.type === 'complete') {
              addLog('Email campaign completed!', 'success')
            } else if (data.type === 'error') {
              addLog(`Error: ${data.message}`, 'error')
            }
          } catch (e) {
            // Ignore JSON parse errors
          }
        }
      }
    } catch (error) {
      addLog(`Error: ${error.message}`, 'error')
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="container">
      <div className="header">
        <h1>📧 MAILER INBOX SENDING</h1>
        <p>Professional Email Campaign Manager</p>
      </div>

      <div className="content">
        <SMTPConfig
          servers={smtpServers}
          setServers={setSmtpServers}
          sendingConfig={sendingConfig}
          setSendingConfig={setSendingConfig}
        />

        <MessageSetup
          config={messageConfig}
          setConfig={setMessageConfig}
          sendingConfig={sendingConfig}
          setSendingConfig={setSendingConfig}
        />

        <SendingControl
          onSend={handleSend}
          sending={sending}
          stats={stats}
        />

        {logs.length > 0 && <LogViewer logs={logs} />}
      </div>
    </div>
  )
}

export default App
