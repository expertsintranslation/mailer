# Project Structure

```
email-sender-app/
├── src/                          # Frontend React application
│   ├── components/               # React components
│   │   ├── SMTPConfig.jsx       # SMTP server configuration
│   │   ├── MessageSetup.jsx     # Email message configuration
│   │   ├── SendingControl.jsx   # Send button and statistics
│   │   └── LogViewer.jsx        # Real-time log viewer
│   ├── App.jsx                  # Main application component
│   ├── main.jsx                 # React entry point
│   └── index.css                # Global styles
│
├── server/                       # Backend Node.js server
│   ├── index.js                 # Express server setup
│   ├── emailSender.js           # Email sending logic with nodemailer
│   └── supabase.js              # Supabase database functions
│
├── supabase/                     # Database migrations
│   └── migrations/
│       └── create_email_sender_tables.sql
│
├── public/                       # Static assets (created by Vite)
├── dist/                        # Production build output
│
├── .env                         # Environment variables (Supabase credentials)
├── package.json                 # Project dependencies and scripts
├── vite.config.js              # Vite configuration
├── index.html                  # HTML entry point
│
├── README.md                    # Full documentation
├── QUICKSTART.md               # Quick start guide
└── PROJECT_STRUCTURE.md        # This file
```

## Key Files Description

### Frontend Components

**App.jsx**
- Main application container
- Manages global state (SMTP servers, message config, sending config, logs)
- Handles email sending flow
- Coordinates communication between components

**SMTPConfig.jsx**
- SMTP server configuration form
- Add/remove multiple SMTP servers
- Configure SSL/TLS settings
- SMTP rotation settings
- Debug level control

**MessageSetup.jsx**
- Email message configuration
- From/Reply-To settings
- Subject and body editor
- Pattern generator for random strings
- Attachment upload
- Dynamic tag information

**SendingControl.jsx**
- Send button
- Real-time statistics (Total, Sent, Failed, Progress)
- Progress bar during sending

**LogViewer.jsx**
- Real-time log display
- Color-coded log levels (success, error, info, warning)
- Auto-scroll to latest logs
- Timestamp for each log entry

### Backend Files

**server/index.js**
- Express server setup
- API endpoints
- File upload handling with Multer
- CORS configuration
- Streaming response for real-time updates

**server/emailSender.js**
- Core email sending logic
- Nodemailer transporter creation
- Pattern replacement (##az-{5}##, !!EMAIL!!, etc.)
- SMTP server rotation
- BCC batch processing
- Pause and reconnect logic
- Error handling and logging

**server/supabase.js**
- Supabase client initialization
- Database functions for email lists
- Campaign logging
- User data management

### Configuration Files

**vite.config.js**
- Vite bundler configuration
- Proxy setup for API calls
- React plugin configuration

**package.json**
- Project metadata
- Dependencies (React, Express, Nodemailer, Supabase)
- NPM scripts (dev, build, server)

**.env**
- Supabase URL and API key
- Environment-specific configuration

## Data Flow

1. **User Input** → Components collect SMTP servers, message config, email list
2. **Send Action** → App.jsx sends data to `/api/send-emails` endpoint
3. **Backend Processing** → server/emailSender.js processes emails with nodemailer
4. **Real-time Updates** → Streaming response sends logs back to frontend
5. **Display** → LogViewer and SendingControl show progress
6. **Database** → Campaign data saved to Supabase (optional)

## API Communication

```
Frontend (React)
    ↓ POST /api/send-emails (multipart/form-data)
Backend (Express)
    ↓ Parse request
    ↓ Create nodemailer transporter
    ↓ Send emails with streaming logs
    ↑ JSON streaming response
Frontend (React)
    ↑ Update logs and progress in real-time
```

## Component Communication

```
App.jsx (Parent)
  ├─→ SMTPConfig (child)
  │     ├─ servers state
  │     └─ sendingConfig state
  │
  ├─→ MessageSetup (child)
  │     ├─ messageConfig state
  │     └─ sendingConfig state
  │
  ├─→ SendingControl (child)
  │     ├─ stats state
  │     └─ handleSend function
  │
  └─→ LogViewer (child)
        └─ logs state
```

## State Management

All state is managed in App.jsx and passed down to child components as props:

- **smtpServers** - Array of SMTP server configuration strings
- **messageConfig** - Email message settings (from, subject, body, etc.)
- **sendingConfig** - Sending behavior (pause, reconnect, BCC, etc.)
- **logs** - Array of log entries with timestamp and level
- **stats** - Campaign statistics (sent, failed, total, progress)
- **sending** - Boolean flag for send operation in progress

## Technologies Used

- **React 18** - UI framework with hooks
- **Vite** - Fast build tool and dev server
- **Express** - Node.js web server
- **Nodemailer** - Email sending library
- **Supabase** - PostgreSQL database with auth
- **Multer** - File upload handling
- **CORS** - Cross-origin resource sharing

## Development Workflow

1. Start backend: `npm run server`
2. Start frontend: `npm run dev`
3. Make changes to components or server files
4. Hot reload automatically updates the app
5. Test email sending with debug mode enabled
6. Build for production: `npm run build`
