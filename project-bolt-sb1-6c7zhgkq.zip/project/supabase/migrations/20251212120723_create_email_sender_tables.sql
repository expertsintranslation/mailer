/*
  # Create Email Sender Application Tables

  1. New Tables
    - `email_lists`
      - `id` (uuid, primary key)
      - `name` (text) - Name of the email list
      - `emails` (text array) - Array of email addresses
      - `email_count` (integer) - Count of emails in the list
      - `user_id` (text) - User identifier
      - `created_at` (timestamptz) - Creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp
    
    - `campaigns`
      - `id` (uuid, primary key)
      - `name` (text) - Campaign name
      - `email_list_id` (uuid) - Reference to email_lists
      - `from_email` (text) - Sender email
      - `from_name` (text) - Sender name
      - `subject` (text) - Email subject
      - `message` (text) - Email body
      - `total_sent` (integer) - Total emails sent
      - `total_failed` (integer) - Total emails failed
      - `status` (text) - Campaign status (pending, running, completed, failed)
      - `user_id` (text) - User identifier
      - `created_at` (timestamptz) - Creation timestamp
      - `completed_at` (timestamptz) - Completion timestamp

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
*/

-- Create email_lists table
CREATE TABLE IF NOT EXISTS email_lists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  emails text[] NOT NULL DEFAULT '{}',
  email_count integer NOT NULL DEFAULT 0,
  user_id text NOT NULL DEFAULT 'default',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create campaigns table
CREATE TABLE IF NOT EXISTS campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email_list_id uuid REFERENCES email_lists(id) ON DELETE SET NULL,
  from_email text NOT NULL,
  from_name text,
  subject text NOT NULL,
  message text NOT NULL,
  total_sent integer DEFAULT 0,
  total_failed integer DEFAULT 0,
  status text DEFAULT 'pending',
  user_id text NOT NULL DEFAULT 'default',
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

-- Enable Row Level Security
ALTER TABLE email_lists ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;

-- Create policies for email_lists
CREATE POLICY "Users can view their own email lists"
  ON email_lists
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = user_id);

CREATE POLICY "Users can insert their own email lists"
  ON email_lists
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Users can update their own email lists"
  ON email_lists
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = user_id)
  WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Users can delete their own email lists"
  ON email_lists
  FOR DELETE
  TO authenticated
  USING (auth.uid()::text = user_id);

-- Create policies for campaigns
CREATE POLICY "Users can view their own campaigns"
  ON campaigns
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = user_id);

CREATE POLICY "Users can insert their own campaigns"
  ON campaigns
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Users can update their own campaigns"
  ON campaigns
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = user_id)
  WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Users can delete their own campaigns"
  ON campaigns
  FOR DELETE
  TO authenticated
  USING (auth.uid()::text = user_id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_email_lists_user_id ON email_lists(user_id);
CREATE INDEX IF NOT EXISTS idx_email_lists_created_at ON email_lists(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_campaigns_user_id ON campaigns(user_id);
CREATE INDEX IF NOT EXISTS idx_campaigns_status ON campaigns(status);
CREATE INDEX IF NOT EXISTS idx_campaigns_created_at ON campaigns(created_at DESC);
