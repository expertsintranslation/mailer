# Quick Start Guide

## Start the Application

### Step 1: Start the Backend Server

Open a terminal and run:

```bash
npm run server
```

You should see: `Email sender server running on http://localhost:3001`

### Step 2: Start the Frontend (In a New Terminal)

```bash
npm run dev
```

The app will open at: `http://localhost:5173`

## First Email Campaign in 5 Minutes

### 1. Add SMTP Server

- **SMTP IP:** `smtp.gmail.com` (or your SMTP server)
- **Port:** `587`
- **Username:** Your email
- **Password:** Your app password
- **Security:** Select TLS
- Click **"Add SMTP"**

### 2. Configure Message

- **Your Email:** sender@example.com
- **Your Name:** Your Name
- **Subject:** Test Email ##09-{4}##
- **Message:**
```html
<h1>Hello !!EMAIL!!</h1>
<p>This is a test email sent on !!DATE!! at !!TIME!!</p>
<p>Your confirmation code: ##az-AZ-09-{10}##</p>
```

### 3. Add Recipients

In the Email List box, add one email per line:
```
test1@example.com
test2@example.com
```

### 4. Send!

Click **"Send Messages"** and watch the real-time logs!

## Tips

- **Debug Mode:** Set Debug Level to 2-3 to see detailed SMTP communication
- **BCC Mode:** Check "IS BCC" when adding SMTP for batch sending
- **Patterns:** Use `##az-{5}##` for random strings in subject/body
- **Pause:** Set pause to avoid rate limits (e.g., 5 sec every 50 emails)

## Common Issues

**Connection Failed:**
- Check SMTP credentials
- Verify port and security settings
- Enable "Less secure apps" or create app password for Gmail

**Emails in Spam:**
- Use authenticated SMTP
- Add SPF/DKIM records to your domain
- Avoid spam words in subject

**Rate Limit Errors:**
- Add pause between sends
- Use multiple SMTP servers with rotation
- Reduce sending speed

## Need Help?

Check the full README.md for detailed documentation!
