# Email Sender Application

A modern, full-featured email campaign manager converted from PHP to React.js. This application allows you to send bulk emails with advanced features like SMTP rotation, BCC mode, pattern generation, and real-time logging.

## Features

### 🚀 Core Features
- **Multiple SMTP Server Support** - Configure multiple SMTP servers with rotation
- **BCC Mode** - Send emails in batches using BCC for efficiency
- **SMTP Rotation** - Automatically rotate between multiple SMTP servers
- **Pattern Generation** - Generate random strings in email subjects and bodies
- **Real-time Logging** - Monitor email sending progress in real-time
- **Attachment Support** - Send emails with file attachments
- **Priority Control** - Set email priority (High, Normal, Low)
- **Pause & Reconnect** - Configure pauses between sends and reconnection intervals

### 📧 Email Features
- HTML or plain text emails
- Dynamic tags: `!!EMAIL!!`, `!!DATE!!`, `!!TIME!!`
- Random pattern generation: `##az-AZ-09-{10}##`
- Custom reply-to addresses
- Reading confirmation support
- Multiple encoding options

### 🗄️ Database Integration
- Supabase integration for storing email lists
- Campaign tracking and history
- User-specific data isolation with RLS

## Technology Stack

- **Frontend:** React 18, Vite
- **Backend:** Node.js, Express
- **Email:** Nodemailer
- **Database:** Supabase (PostgreSQL)
- **Styling:** Pure CSS with modern design

## Getting Started

### Prerequisites

- Node.js 18+ installed
- Supabase account (already configured)
- SMTP server credentials (optional - can use localhost)

### Installation

1. **Install dependencies:**
```bash
npm install
```

2. **Environment variables are already configured in `.env`**

3. **Database is already set up** - Tables created via migration

### Running the Application

#### Option 1: Run Frontend and Backend Separately

**Terminal 1 - Start Backend Server:**
```bash
npm run server
```
The backend will run on `http://localhost:3001`

**Terminal 2 - Start Frontend:**
```bash
npm run dev
```
The frontend will run on `http://localhost:5173`

#### Option 2: Production Build

```bash
npm run build
npm run preview
```

## Usage Guide

### 1. Configure SMTP Servers

1. Enter your SMTP server details:
   - **SMTP IP/Host:** Your mail server address
   - **Port:** Usually 25, 465 (SSL), or 587 (TLS)
   - **Username/Password:** Your SMTP credentials
   - **Security:** Select SSL, TLS, or NON

2. Click "Add SMTP" to add the server to your configuration

3. Configure rotation (optional): Set how many emails to send before rotating to the next SMTP server

### 2. Setup Your Message

1. **Sender Information:**
   - Your Email (or check "EMAIL as LOGIN" to use SMTP username)
   - Your Name
   - Reply-To address

2. **Email Content:**
   - Subject line
   - Message body (HTML or Plain Text)
   - Use dynamic tags and patterns for personalization

3. **Dynamic Tags:**
   - `!!EMAIL!!` - Replaced with recipient's email
   - `!!DATE!!` - Current date
   - `!!TIME!!` - Current time
   - `##az-AZ-09-{10}##` - Random 10-character string

### 3. Configure Sending Options

- **Reconnect After:** Number of emails before reconnecting to SMTP
- **Send Pause:** Pause duration (seconds) after sending X emails
- **BCC Count:** Number of recipients per BCC batch
- **Debug Level:** 0-4 for troubleshooting

### 4. Add Email List

Enter email addresses in the Email List field, one per line:
```
user1@example.com
user2@example.com
user3@example.com
```

### 5. Send Emails

Click "Send Messages" to start the campaign. Monitor progress in real-time via:
- Statistics dashboard (Total, Sent, Failed, Progress)
- Live log viewer with color-coded messages

## Pattern Generation Examples

Generate random strings in your emails:

- `##az-{5}##` → Random 5 lowercase letters: `abcde`
- `##AZ-{5}##` → Random 5 uppercase letters: `ABCDE`
- `##09-{5}##` → Random 5 digits: `12345`
- `##az-AZ-09-{10}##` → Random 10 mixed characters: `aBc123XyZ4`

Example usage in subject:
```
Hello !!EMAIL!! - Your code is ##09-{6}##
```

Result:
```
Hello john@example.com - Your code is 847392
```

## SMTP Configuration Examples

### Gmail (with App Password)
```
Host: smtp.gmail.com
Port: 587
Security: TLS
Username: your-email@gmail.com
Password: your-app-password
```

### SendGrid
```
Host: smtp.sendgrid.net
Port: 587
Security: TLS
Username: apikey
Password: your-sendgrid-api-key
```

### Mailgun
```
Host: smtp.mailgun.org
Port: 587
Security: TLS
Username: postmaster@yourdomain.com
Password: your-mailgun-password
```

### Localhost (No Authentication)
```
Leave SMTP fields empty to use PHP mail() equivalent
```

## Database Schema

### Tables Created

**email_lists**
- Stores email list collections
- Fields: name, emails[], email_count, user_id

**campaigns**
- Tracks email campaigns
- Fields: name, from_email, subject, message, total_sent, total_failed, status

## API Endpoints

### POST /api/send-emails
Send bulk emails with streaming response

**Request Body:**
```json
{
  "smtpServers": ["server1:port:user:pass:SSL:BCC"],
  "messageConfig": {
    "from": "sender@example.com",
    "fromName": "Sender Name",
    "subject": "Email Subject",
    "message": "Email body",
    "contentType": "html"
  },
  "sendingConfig": {
    "reconnectAfter": 100,
    "pauseSeconds": 5,
    "pauseEveryEmails": 50,
    "bccCount": 100
  },
  "emails": ["email1@example.com", "email2@example.com"]
}
```

**Response:** JSON streaming with real-time progress updates

## Security Features

- Row Level Security (RLS) enabled on all tables
- User-specific data isolation
- Secure SMTP credential handling
- No plain text password storage in logs

## Troubleshooting

### SMTP Connection Issues
1. Enable debug level 2-4 to see detailed SMTP logs
2. Verify SMTP credentials and server address
3. Check firewall settings for outbound SMTP ports
4. Try different security settings (SSL/TLS/NON)

### Emails Going to Spam
1. Use authenticated SMTP servers
2. Configure SPF and DKIM records for your domain
3. Avoid spam trigger words
4. Use proper from addresses

### Rate Limiting
1. Configure "Reconnect After" to break up large sends
2. Use "Send Pause" to throttle sending speed
3. Rotate between multiple SMTP servers

## Performance Tips

- Use BCC mode for large campaigns (more efficient)
- Configure SMTP rotation to distribute load
- Set appropriate pause intervals to avoid rate limits
- Use multiple SMTP servers for high-volume sending

## License

This is a conversion of a PHP mailer application to modern React.js stack.

## Credits

Original PHP Version: BY RFX (SKYPE: KIMONO238)
React Conversion: Modern full-stack implementation with Supabase integration
