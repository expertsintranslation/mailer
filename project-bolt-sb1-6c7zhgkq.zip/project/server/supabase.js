import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.VITE_SUPABASE_URL
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY

export const supabase = createClient(supabaseUrl, supabaseKey)

// Save email list to database
export async function saveEmailList(name, emails, userId = 'default') {
  try {
    const { data, error } = await supabase
      .from('email_lists')
      .insert({
        name,
        emails,
        user_id: userId,
        email_count: emails.length
      })
      .select()
      .maybeSingle()

    if (error) throw error
    return data
  } catch (error) {
    console.error('Error saving email list:', error)
    throw error
  }
}

// Get all email lists
export async function getEmailLists(userId = 'default') {
  try {
    const { data, error } = await supabase
      .from('email_lists')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })

    if (error) throw error
    return data
  } catch (error) {
    console.error('Error fetching email lists:', error)
    throw error
  }
}

// Save campaign log
export async function saveCampaignLog(campaignData) {
  try {
    const { data, error } = await supabase
      .from('campaigns')
      .insert(campaignData)
      .select()
      .maybeSingle()

    if (error) throw error
    return data
  } catch (error) {
    console.error('Error saving campaign log:', error)
    throw error
  }
}
