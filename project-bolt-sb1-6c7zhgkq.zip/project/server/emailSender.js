import nodemailer from 'nodemailer'

// Generate random string based on pattern
function generateRandomString(pattern) {
  const match = pattern.match(/##([a-zA-Z0-9\-]+)\{(\d+)\}##/)
  if (!match) return pattern

  const types = match[1].split('-')
  const length = parseInt(match[2])

  let characters = ''
  if (types.includes('09')) characters += '0123456789'
  if (types.includes('az')) characters += 'abcdefghijklmnopqrstuvwxyz'
  if (types.includes('AZ')) characters += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

  let result = ''
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length))
  }

  return result
}

// Replace patterns in text
function replacePatterns(text, email = '') {
  // Replace random patterns
  text = text.replace(/##([a-zA-Z0-9\-]+)\{(\d+)\}##/g, (match) => {
    return generateRandomString(match)
  })

  // Replace tags
  text = text.replace(/!!EMAIL!!/g, email)
  text = text.replace(/!!DATE!!/g, new Date().toLocaleDateString())
  text = text.replace(/!!TIME!!/g, new Date().toLocaleTimeString())

  return text
}

// Parse SMTP server string
function parseSMTPServer(serverString) {
  const [host, port, username, password, security, bccMode] = serverString.split(':')
  return {
    host,
    port: parseInt(port) || 25,
    username,
    password,
    security,
    isBCC: bccMode === 'BCC',
    secure: security === 'SSL',
    requireTLS: security === 'TLS'
  }
}

// Create transporter
function createTransporter(server) {
  const config = {
    host: server.host,
    port: server.port,
    secure: server.secure
  }

  if (server.username && server.password) {
    config.auth = {
      user: server.username,
      pass: server.password
    }
  }

  if (server.requireTLS) {
    config.requireTLS = true
    config.tls = {
      rejectUnauthorized: false
    }
  }

  return nodemailer.createTransporter(config)
}

// Sleep function
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

// Main send emails function
export async function sendEmails(
  smtpServers,
  messageConfig,
  sendingConfig,
  emails,
  attachment,
  writeLog
) {
  let sent = 0
  let failed = 0
  let currentServerIndex = 0
  let emailsSinceReconnect = 0
  let emailsSincePause = 0
  let emailsSinceRotate = 0

  // Parse SMTP servers
  const servers = smtpServers.map(parseSMTPServer)
  if (servers.length === 0) {
    throw new Error('No SMTP servers configured')
  }

  let currentServer = servers[currentServerIndex]
  let transporter = createTransporter(currentServer)

  writeLog({ type: 'log', level: 'info', message: `Starting with SMTP server: ${currentServer.host}:${currentServer.port}` })

  // Determine if using BCC mode
  const usingBCC = currentServer.isBCC || sendingConfig.isBCC
  const bccCount = parseInt(sendingConfig.bccCount) || 100

  if (usingBCC) {
    writeLog({ type: 'log', level: 'info', message: `Using BCC mode with ${bccCount} emails per batch` })

    // BCC mode - send in batches
    let bccBatch = []
    let batchNumber = 0

    for (let i = 0; i < emails.length; i++) {
      const email = emails[i].trim()
      if (!email) continue

      bccBatch.push(email)

      if (bccBatch.length >= bccCount || i === emails.length - 1) {
        batchNumber++

        try {
          // Prepare message
          let from = messageConfig.from
          if (messageConfig.useLoginAsEmail && currentServer.username) {
            from = currentServer.username
          }
          // Add random number to from email
          from = from.replace(/(\d+)/, () => Math.floor(Math.random() * 90000) + 10000)

          let replyTo = messageConfig.replyTo
          if (messageConfig.useLoginAsReply && currentServer.username) {
            replyTo = currentServer.username
          }

          const subject = replacePatterns(messageConfig.subject)
          const message = replacePatterns(messageConfig.message)
          const fromName = replacePatterns(messageConfig.fromName)

          const mailOptions = {
            from: `${fromName} <${from}>`,
            bcc: bccBatch,
            subject: subject,
            html: messageConfig.contentType === 'html' ? message : undefined,
            text: messageConfig.contentType === 'plain' ? message : undefined,
            replyTo: replyTo || undefined,
            priority: messageConfig.priority || undefined
          }

          if (attachment) {
            mailOptions.attachments = [{
              filename: attachment.filename,
              content: attachment.content
            }]
          }

          // Send email
          await transporter.sendMail(mailOptions)

          writeLog({
            type: 'log',
            level: 'success',
            message: `BCC Batch #${batchNumber} sent (${bccBatch.length} recipients)`
          })

          sent += bccBatch.length
          emailsSinceReconnect += bccBatch.length
          emailsSincePause += bccBatch.length
          emailsSinceRotate += bccBatch.length

        } catch (error) {
          writeLog({
            type: 'log',
            level: 'error',
            message: `BCC Batch #${batchNumber} failed: ${error.message}`
          })
          failed += bccBatch.length
        }

        writeLog({
          type: 'progress',
          sent,
          failed,
          total: emails.length
        })

        bccBatch = []

        // Handle reconnect
        if (sendingConfig.reconnectAfter > 0 && emailsSinceReconnect >= sendingConfig.reconnectAfter) {
          writeLog({ type: 'log', level: 'info', message: 'Reconnecting to SMTP server...' })
          transporter.close()
          transporter = createTransporter(currentServer)
          emailsSinceReconnect = 0
        }

        // Handle pause
        if (sendingConfig.pauseSeconds > 0 && sendingConfig.pauseEveryEmails > 0) {
          if (emailsSincePause >= sendingConfig.pauseEveryEmails && i < emails.length - 1) {
            const pauseSec = parseInt(sendingConfig.pauseSeconds)
            writeLog({ type: 'log', level: 'warning', message: `Pausing for ${pauseSec} seconds...` })
            await sleep(pauseSec * 1000)
            emailsSincePause = 0
          }
        }

        // Handle rotation
        if (servers.length > 1 && sendingConfig.rotateEvery > 0) {
          if (emailsSinceRotate >= sendingConfig.rotateEvery && i < emails.length - 1) {
            currentServerIndex = (currentServerIndex + 1) % servers.length
            currentServer = servers[currentServerIndex]
            transporter.close()
            transporter = createTransporter(currentServer)
            writeLog({ type: 'log', level: 'info', message: `Rotated to SMTP server: ${currentServer.host}:${currentServer.port}` })
            emailsSinceRotate = 0
            emailsSinceReconnect = 0
          }
        }
      }
    }

  } else {
    // Individual mode - send one by one
    for (let i = 0; i < emails.length; i++) {
      const email = emails[i].trim()
      if (!email) continue

      try {
        // Prepare message
        let from = messageConfig.from
        if (messageConfig.useLoginAsEmail && currentServer.username) {
          from = currentServer.username
        }
        // Add random number to from email
        from = from.replace(/(\d+)/, () => Math.floor(Math.random() * 90000) + 10000)

        let replyTo = messageConfig.replyTo
        if (messageConfig.useLoginAsReply && currentServer.username) {
          replyTo = currentServer.username
        }

        const subject = replacePatterns(messageConfig.subject, email)
        const message = replacePatterns(messageConfig.message, email)
        const fromName = replacePatterns(messageConfig.fromName)

        const mailOptions = {
          from: `${fromName} <${from}>`,
          to: email,
          subject: subject,
          html: messageConfig.contentType === 'html' ? message : undefined,
          text: messageConfig.contentType === 'plain' ? message : undefined,
          replyTo: replyTo || undefined,
          priority: messageConfig.priority || undefined
        }

        if (attachment) {
          mailOptions.attachments = [{
            filename: attachment.filename,
            content: attachment.content
          }]
        }

        // Send email
        await transporter.sendMail(mailOptions)

        writeLog({
          type: 'log',
          level: 'success',
          message: `Line ${i + 1}: Sent to ${email} - OK`
        })

        sent++
        emailsSinceReconnect++
        emailsSincePause++
        emailsSinceRotate++

      } catch (error) {
        writeLog({
          type: 'log',
          level: 'error',
          message: `Line ${i + 1}: Failed to ${email} - ${error.message}`
        })
        failed++
      }

      writeLog({
        type: 'progress',
        sent,
        failed,
        total: emails.length
      })

      // Handle reconnect
      if (sendingConfig.reconnectAfter > 0 && emailsSinceReconnect >= sendingConfig.reconnectAfter) {
        writeLog({ type: 'log', level: 'info', message: 'Reconnecting to SMTP server...' })
        transporter.close()
        transporter = createTransporter(currentServer)
        emailsSinceReconnect = 0
      }

      // Handle pause
      if (sendingConfig.pauseSeconds > 0 && sendingConfig.pauseEveryEmails > 0) {
        if (emailsSincePause >= sendingConfig.pauseEveryEmails && i < emails.length - 1) {
          const pauseSec = parseInt(sendingConfig.pauseSeconds)
          writeLog({ type: 'log', level: 'warning', message: `Pausing for ${pauseSec} seconds...` })
          await sleep(pauseSec * 1000)
          emailsSincePause = 0
        }
      }

      // Handle rotation
      if (servers.length > 1 && sendingConfig.rotateEvery > 0) {
        if (emailsSinceRotate >= sendingConfig.rotateEvery && i < emails.length - 1) {
          currentServerIndex = (currentServerIndex + 1) % servers.length
          currentServer = servers[currentServerIndex]
          transporter.close()
          transporter = createTransporter(currentServer)
          writeLog({ type: 'log', level: 'info', message: `Rotated to SMTP server: ${currentServer.host}:${currentServer.port}` })
          emailsSinceRotate = 0
          emailsSinceReconnect = 0
        }
      }
    }
  }

  // Close transporter
  transporter.close()

  writeLog({
    type: 'log',
    level: 'success',
    message: `Campaign complete! Sent: ${sent}, Failed: ${failed}, Total: ${emails.length}`
  })
}
