import express from 'express'
import cors from 'cors'
import multer from 'multer'
import { sendEmails } from './emailSender.js'

const app = express()
const PORT = 3001

// Middleware
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Multer for file uploads
const storage = multer.memoryStorage()
const upload = multer({ storage })

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Email sender API is running' })
})

// Send emails endpoint
app.post('/api/send-emails', upload.single('attachment'), async (req, res) => {
  try {
    const { smtpServers, messageConfig, sendingConfig, emails } = req.body

    // Parse JSON strings
    const parsedServers = JSON.parse(smtpServers)
    const parsedMessageConfig = JSON.parse(messageConfig)
    const parsedSendingConfig = JSON.parse(sendingConfig)
    const parsedEmails = JSON.parse(emails)

    // Get attachment if exists
    const attachment = req.file
      ? {
          filename: req.file.originalname,
          content: req.file.buffer
        }
      : null

    // Set headers for streaming
    res.setHeader('Content-Type', 'application/json')
    res.setHeader('Transfer-Encoding', 'chunked')

    // Create a write stream function
    const writeLog = (data) => {
      res.write(JSON.stringify(data) + '\n')
    }

    // Send emails with streaming logs
    await sendEmails(
      parsedServers,
      parsedMessageConfig,
      parsedSendingConfig,
      parsedEmails,
      attachment,
      writeLog
    )

    // Complete
    writeLog({ type: 'complete', message: 'All emails processed' })
    res.end()
  } catch (error) {
    console.error('Error:', error)
    if (!res.headersSent) {
      res.status(500).json({ error: error.message })
    } else {
      res.write(JSON.stringify({ type: 'error', message: error.message }) + '\n')
      res.end()
    }
  }
})

app.listen(PORT, () => {
  console.log(`Email sender server running on http://localhost:${PORT}`)
})
